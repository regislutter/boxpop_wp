<?php global $wpdb; ?>

DROP TABLE IF EXISTS <?php echo $wpdb->prefix; ?>cities;
DROP TABLE IF EXISTS <?php echo $wpdb->prefix; ?>countries;
DROP TABLE IF EXISTS <?php echo $wpdb->prefix; ?>states;
